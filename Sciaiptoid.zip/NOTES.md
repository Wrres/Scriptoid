# NOTES

```
Simonaut_: ChannelManager in discord.js sounds like what you may need to look into
```


## BALANCE
![](https://cdn.discordapp.com/attachments/633416459170742274/900445412379476038/unknown.png)


## CITIES MISSING IN SERBIA
```json
{
		"city": "Šid",
    "population": 14893,
		"country": [
			"RS",
			"Serbia"
		]
	},
  {
		"city": "Paraćin",
    "population": 25104,
		"country": [
			"RS",
			"Serbia"
		]
	},
```
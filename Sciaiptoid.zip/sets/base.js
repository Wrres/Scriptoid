const BASE = {
	"footer": "Write the Latin transliteration of the given  letter.",
	"sets": [
    
  ]
};

module.exports = BASE;